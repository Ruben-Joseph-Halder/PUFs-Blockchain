package main

import (
    "flag"
    "fmt"
    "os"
    "io/ioutil"
    "strconv"

    "Ruben"
)

/*
文件加密————分块：
    最后一个shard的size明显小于之前的几个shards
eg:
    go run 1-1FileCipherShards.go \
                    -file  File/8.txt \
                    -keyF  File/key_file/8-cipherKey.txt \
                    -size  1


        The file to be encrpted&sharded is: File/8.txt
        The key-file is: File/8-cipherKey.txt

        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/8-cipher.txt is create.
        shard's number: 3 2896
        create shards: 1CipherShards/8-cipher-0.txt
        create shards: 1CipherShards/8-cipher-1.txt
        create shards: 1CipherShards/8-cipher-2.txt

 */

// 原文件路径（加密——分块）
var filePath *string = flag.String("file", "Null",  "Please input the file you want to encrpt: ")
// 加密原文件的秘钥——key
var key      *string = flag.String("keyF",  "Null", "Please input the secret key(16Byte) to encode the file: ")
// shard的大小——size（Kb）
var size     *string = flag.String("size", "0(kb)", "Please input the size of a shard.")

func main() {
    flag.Parse()

    //1、加密原文件
    // 1-1、读取文件内容
    plain, err := ioutil.ReadFile(*filePath)
    if err != nil {
        fmt.Print("err:", err)
        fmt.Print("\neg: go run 1-1FileCipherShards.go -file File/8.txt -key File/8-cipherKey.txt -size 1 \n")
    }else{
        fmt.Printf("\n%s %s","The file to be encrpted&sharded is:", *filePath)
        plainText := []byte(plain)

        // 1-2、读取对称密钥——key
        keyplain, err := ioutil.ReadFile(*key)
        if err != nil {
            fmt.Print("err:", err)
        }else{
            fmt.Printf("\n%s %s","The key-file is:", *key)
            fmt.Println("\n")
            key := []byte(keyplain)

            // 1-3、加密——【 K(R) 】
            cipherText := Ruben.AesCBC_Encrypt(plainText, key)

            // 1-4、将得到的密文存储到"1CipherShards"文件夹下
            if cipherText != nil {
                Folder := "1CipherShards/"
                ExtraNmae := "-cipher"
                fileName := Ruben.WriteInFile(Folder, ExtraNmae, *filePath, cipherText)

                //2、分块
                // 2-1、读取密文
                file, err := os.Open(fileName)
                if err != nil {
                    fmt.Println("failed to open:", fileName)
                    fmt.Print("\neg: go run 1-1FileCipherShards.go -file File/8.txt -key File/8-cipherKey.txt -size 1 \n")
                }else{
                    defer file.Close()

                    // 2-2、选定存储shards的文件夹，开始分块
                    _, _, filenameOnly, fileSuffix := Ruben.DirFileNameSuffix(fileName)
                    size, _ := strconv.Atoi(*size)
                    Folder := "1CipherShards/"
                    Ruben.SplitFile(file, size*1024, Folder, filenameOnly, fileSuffix)

                }

            }

        }

    }

}
