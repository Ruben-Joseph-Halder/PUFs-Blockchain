package main

import (
    "fmt"
    "io/ioutil"
    "flag"
    "os"

    "Ruben"
)

/*
Shards————merge————file
eg:
    go run 2ShardsCipherFile.go \
                    -shard  2RetrieveMerge/7Zip-cipher.zip \
                    -keyF   File/key_file/8-cipherKey.txt

        The folder that contains the shards is:  F:\PyCharm 2017.2.3\go-examples\src\File_Operation\2RetrieveMerge/
        The merged file is in the "File" folder.

        The cipher to be decrypted is: 7Zip-cipher-merged.zip
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/7Zip-cipher-decrypt.zip is create.

*/

//shards(8.txt,7Zip.zip)路径——2RetrieveMerge/file
var filePath *string = flag.String("shard", "2RetrieveMerge/file", "Please input the shard path:")
//解密密文的秘钥
var key      *string = flag.String("keyF", "Null", "Please input the secret key(16Byte) to decrypt the cipher: ")

func main(){
    flag.Parse()

    //1、合并shards
    // 按"文件名后缀过滤"合并文件夹"2Retrieve"中的shards，得到"8-merged.txt"存放在"2Retrieve"文件夹中
    dir, _ := os.Getwd() //当前的目录
    fileDir, _, filenameOnly, fileSuffix := Ruben.DirFileNameSuffix(*filePath)
    rootPath := dir + "\\" + fileDir
    fmt.Println("\nThe folder that contains the shards is: ", rootPath)
    mergeFilePath := Ruben.MergeFile(rootPath, filenameOnly, fileSuffix)

/****************************************************************************************************************/
    //2、解密密文，得到明文(原文)
    // 读取密文
    cipher, err := ioutil.ReadFile(mergeFilePath)
    if err != nil {
        fmt.Print("err:", err)
    }else{
        fmt.Printf("\n%s %s","The cipher to be decrypted is:", filenameOnly + "-merged" + fileSuffix)
        cipherText := []byte(cipher)
        // 读取对称密钥——key
        keyplain, err := ioutil.ReadFile(*key)
        if err != nil {
            fmt.Print("err:", err)
        }else{
            key := []byte(keyplain)
            // 解密
            plain := Ruben.AesCBC_Decrypt(cipherText, key)
            // 将明文写入文件： 将得到的明文存储到"File"文件夹下
            if plain != nil {
                Folder := "File/"
                ExtraNmae := "-decrypt"
                Ruben.WriteInFile(Folder, ExtraNmae, *filePath, plain)
                fmt.Println("\n")

            }

        }

    }

}
