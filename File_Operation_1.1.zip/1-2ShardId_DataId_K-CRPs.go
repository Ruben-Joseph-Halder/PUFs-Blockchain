package main

import (
    "fmt"
    "os"
    "flag"
    "io/ioutil"
    "strconv"

    "Ruben"
)

/**
计算ShardId————DataId————cipherCRPs
                                            ShardId = H256(IP, x,  shard)
                                            DataId  = H256[C, K(R),ShardId]

                                            send：shard、PKa[C,K(R)]
eg:
    go run 1-2ShardId_DataId_K-CRPs.go \
                    -ip     192.168.90.12 \
                    -n      4 \
                    -shard  1CipherShards/7Zip-cipher.zip \
                    -c      CRPs/Challenge/challenge_128_819200_0_220370.bin \
                    -r      CRPs/Response/response_128_819200_0_220370.bin \
                    -keyR   File/key_response/8-cipherResponseKey.txt \
                    -pub    File/Node_pubKey/node_eccpublic.pem



        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-0-ShardId.zip is create.
        The key-file is: F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/key_response/\8-cipherResponseKey-0.txt
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-0-DataId.zip is create.
        The key-file is: F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/Node_pubKey/\node_eccpublic-0.pem
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-node_eccpublic-0-cipherCRPs.bin is create.


        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-1-ShardId.zip is create.
        The key-file is: F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/key_response/\8-cipherResponseKey-1.txt
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-1-DataId.zip is create.
        The key-file is: F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/Node_pubKey/\node_eccpublic-1.pem
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-node_eccpublic-1-cipherCRPs.bin is create.


        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-2-ShardId.zip is create.
        The key-file is: F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/key_response/\8-cipherResponseKey-2.txt
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-2-DataId.zip is create.
        The key-file is: F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/Node_pubKey/\node_eccpublic-2.pem
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-node_eccpublic-2-cipherCRPs.bin is create.


        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-3-ShardId.zip is create.
        The key-file is: F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/key_response/\8-cipherResponseKey-3.txt
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-3-DataId.zip is create.
        The key-file is: F:\PyCharm 2017.2.3\go-examples\src\File_Operation\File/Node_pubKey/\node_eccpublic-3.pem
        The F:\PyCharm 2017.2.3\go-examples\src\File_Operation\1CipherShards/\7Zip-cipher-node_eccpublic-3-cipherCRPs.bin is create.

**/


var IPaddress      *string = flag.String("ip",    "Null", "Please input the IPaddress: ")
var Number         *string = flag.String("n",     "0",    "Please input the ShardsNum: ")
var shardPath      *string = flag.String("shard", "Null", "Please input the shard name: ")

var challengPath   *string = flag.String("c",     "Null", "Please input the challengPath: ")
var responsePath   *string = flag.String("r",     "Null", "Please input the responsePath: ")
var key            *string = flag.String("keyR",   "Null", "Please input the secret key(16Byte) to encode the response: ")

var receiverPubKey *string = flag.String("pub",   "Null", "Please input the secret key1(16Byte): ")

func main(){
//                                            ShardId = H256(IP, x,  shard)
//                                            DataId  = H256[C, K(R),ShardId]
    flag.Parse()

    //shard's number——n
    n,error := strconv.Atoi(*Number)
    if error != nil{
        fmt.Println("字符串转换成整数失败")
    }

    dir, _ := os.Getwd() //当前的目录
    shardDir,          _, shardNameOnly,              shardSuffix              := Ruben.DirFileNameSuffix(*shardPath)
    challengDir,       _, challengFilenameOnly,       challengFileSuffix       := Ruben.DirFileNameSuffix(*challengPath)
    responseDir,       _, responseFilenameOnly,       responseFileSuffix       := Ruben.DirFileNameSuffix(*responsePath)
    keyDir,            _, keyFilenameOnly,            keyFileSuffix            := Ruben.DirFileNameSuffix(*key)
    receiverPubKeyDir, _, receiverPubKeyFilenameOnly, receiverPubKeyFileSuffix := Ruben.DirFileNameSuffix(*receiverPubKey)


    //计算n个ShardId&DataId，并写入文件
    for x := 0; x < n; x++ {
        //1、计算ShardId = H256(IP,x,shard)
        shardName := shardNameOnly + "-" + strconv.Itoa(x) + shardSuffix
        filePath := dir + "\\" + shardDir + shardName
        ShardId := Ruben.ShardIdHash256(filePath, string(*IPaddress), x)
        // 将ShardId写入文件
        hashFile := dir + "\\" + shardDir + "\\" + shardNameOnly + "-" + strconv.Itoa(x) + "-ShardId" + shardSuffix
        Ruben.WriteHashInFile(hashFile, ShardId)


        //2、计算DataId  = H256[C, K(R),ShardId]
        // 2-1、读激励——C
        challeng, err := ioutil.ReadFile(dir + "\\" + challengDir + "\\" + challengFilenameOnly + "-" + strconv.Itoa(x) + challengFileSuffix)
        if err != nil {
            fmt.Print("err:", err)
            fmt.Print("\nPlease read the README.\n")
        } else{
            // 2-2、读响应——R
            response, err := ioutil.ReadFile(dir + "\\" + responseDir + "\\" + responseFilenameOnly + "-" + strconv.Itoa(x) + responseFileSuffix)
            if err != nil {
                fmt.Print("err:", err)
            } else{
                plainText := []byte(response)
                // 2-3、读取密钥——key
                keyplain, err := ioutil.ReadFile(dir + "\\" + keyDir + "\\" + keyFilenameOnly + "-" + strconv.Itoa(x) + keyFileSuffix)
                if err != nil {
                    fmt.Print("err:", err)
                }else{
                    fmt.Printf("\n%s %s","The key-file is:", dir + "\\" + keyDir + "\\"+ keyFilenameOnly + "-" + strconv.Itoa(x) + keyFileSuffix)
                    key := []byte(keyplain)
                    // 2-4、加密响应R——K(R)
                    cipherResponse := Ruben.AesCBC_Encrypt(plainText, key)
                    if cipherResponse != nil{
                        // 2-5、计算DataId = H256[ C,K(R),ShardId ]
                        data := string(challeng) + string(cipherResponse) + ShardId
                        DataId := Ruben.DataIdHash256(data)
                        // 将DataId写入文件
                        DataIdfile := dir + "\\" + shardDir + "\\" + shardNameOnly + "-" + strconv.Itoa(x) + "-DataId" + shardSuffix
                        Ruben.WriteHashInFile(DataIdfile, DataId)


                        //3、计算cipherCRPs = Pka[ C, K(R) ]，并写入文件
                        plainCRPs := string(challeng) + string(cipherResponse)
                        /**
                            这里传入的私钥和公钥要用"GetECCKey"里面得到的私钥和公钥！
                            如果自己封装的话，获取密钥时传入的第一个参数是要用这条曲线"elliptic.P256()"，如果用别的会报无效公钥错误！
                                eg：用P521()这条曲线。
                        **/
                        // 3-1、读取Receiver的公钥
                        eccpublic, err := ioutil.ReadFile(dir + "\\" + receiverPubKeyDir + "\\" + receiverPubKeyFilenameOnly + "-" + strconv.Itoa(x) + receiverPubKeyFileSuffix)
                        fmt.Printf("\n%s %s","The key-file is:", dir + "\\" + receiverPubKeyDir + "\\" + receiverPubKeyFilenameOnly + "-" + strconv.Itoa(x) + receiverPubKeyFileSuffix)
                        if err != nil {
                            fmt.Print("err:", err)
                        } else{
                            publicKey:=[]byte(string(eccpublic))
                            // 3-2、公钥加密
                            cipherCRPs,_:=Ruben.EccPublicEncrypt([]byte(plainCRPs),publicKey)
                            // fmt.Println("ECC传入公钥加密的密文为：",hex.EncodeToString(cipherCRPs))
                            // 写入文件
                            cipherCRPsPath := dir + "\\" + shardDir + "\\" + shardNameOnly + "-" + receiverPubKeyFilenameOnly + "-" + strconv.Itoa(x) +  "-cipherCRPs" + challengFileSuffix
                            Ruben.WriteHashInFile(cipherCRPsPath, string(cipherCRPs))
                            fmt.Println("\n")

                        }

                    }

                }

            }

        }

    }

}



